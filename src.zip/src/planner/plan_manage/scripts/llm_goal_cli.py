#!/usr/bin/env python3
"""
CLI: parse natural language with LLM and publish /move_base_simple/goal (PoseStamped).
"""
import argparse
import json
import os
import sys
from pathlib import Path

import rospy
from geometry_msgs.msg import PoseStamped


def _repo_root() -> Path:
    # .../src/planner/plan_manage/scripts/llm_goal_cli.py -> repo root
    return Path(__file__).resolve().parents[4]


def _load_landmarks(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"Landmark file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _resolve_landmark(landmarks: dict, name: str) -> dict:
    if name in landmarks:
        return landmarks[name]
    # 允许简单的大小写/空格容错
    normalized = name.strip()
    if normalized in landmarks:
        return landmarks[normalized]
    raise KeyError(f"Landmark not configured: {name}")


def _build_pose_stamped(x: float, y: float, z: float, yaw: float = 0.0) -> PoseStamped:
    # Only yaw=0 is needed for now; use identity quaternion.
    msg = PoseStamped()
    msg.header.stamp = rospy.Time.now()
    msg.header.frame_id = "world"
    msg.pose.position.x = x
    msg.pose.position.y = y
    msg.pose.position.z = z
    msg.pose.orientation.x = 0.0
    msg.pose.orientation.y = 0.0
    msg.pose.orientation.z = 0.0
    msg.pose.orientation.w = 1.0
    return msg


def _parse_args() -> argparse.Namespace:
    default_landmarks = _repo_root() / "src" / "planner" / "plan_manage" / "config" / "llm_landmarks.json"
    parser = argparse.ArgumentParser(
        description="LLM->Ego Planner CLI (/move_base_simple/goal)"
    )
    parser.add_argument("text", help='Natural language command, e.g. "take me to charger"')
    parser.add_argument("--ollama-url", default="http://127.0.0.1:11434")
    parser.add_argument("--model", default="llama3.2:1b-instruct-q4_0")
    parser.add_argument("--landmarks", default=str(default_landmarks))
    parser.add_argument("--min-confidence", type=float, default=0.5)
    parser.add_argument("--dry-run", action="store_true", help="Parse only, do not publish")
    parser.add_argument("--override-x", type=float, default=None)
    parser.add_argument("--override-y", type=float, default=None)
    parser.add_argument("--override-z", type=float, default=None)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()

    # 延迟导入，避免 ROS 环境未初始化导致失败
    repo_root = _repo_root()
    sys.path.insert(0, str(repo_root))
    from semantic import SemanticNavigator  # noqa: E402

    landmarks = _load_landmarks(Path(args.landmarks))

    nav = SemanticNavigator(ollama_url=args.ollama_url)
    nav.model = args.model
    result = nav.parse_navigation_intent(args.text)

    action = result.get("action")
    landmark = result.get("landmark")
    confidence = float(result.get("confidence", 0.0))

    print("LLM result:", json.dumps(result, ensure_ascii=False, indent=2))

    if action != "navigate":
        print(f"Action is not navigate (action={action}); skip publishing.")
        return 1
    if confidence < args.min_confidence:
        print(f"Confidence too low: {confidence:.2f} < {args.min_confidence:.2f}; skip publishing.")
        return 1
    if not landmark:
        print("No landmark parsed; skip publishing.")
        return 1

    if args.override_x is not None and args.override_y is not None and args.override_z is not None:
        x, y, z = args.override_x, args.override_y, args.override_z
        yaw = 0.0
    else:
        target = _resolve_landmark(landmarks, landmark)
        x = float(target["x"])
        y = float(target["y"])
        z = float(target.get("z", 1.0))
        yaw = float(target.get("yaw", 0.0))

    pose_msg = _build_pose_stamped(x, y, z, yaw=yaw)

    if args.dry_run:
        print(f"[dry-run] target: x={x:.2f}, y={y:.2f}, z={z:.2f}, yaw={yaw:.2f}")
        return 0

    rospy.init_node("llm_goal_cli", anonymous=True)
    pub = rospy.Publisher("/move_base_simple/goal", PoseStamped, queue_size=1)
    rospy.sleep(0.2)
    pub.publish(pose_msg)
    rospy.sleep(0.2)
    print(f"Published /move_base_simple/goal: x={x:.2f}, y={y:.2f}, z={z:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
